# __init__.py

# version of the module

__version__="1.1.1"
